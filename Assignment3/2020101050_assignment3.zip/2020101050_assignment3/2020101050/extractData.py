from tqdm import tqdm
import json
import re
import gzip
import shutil

# with gzip.open('reviews_Movies_and_TV.json.gz', 'rb') as f_in:
#     with open('reviews_Movies_and_TV.json', 'wb') as f_out:
#         shutil.copyfileobj(f_in, f_out)

with open("reviews.txt","w") as fp:
    with open('data.json') as file:
        for line in tqdm(file):
            fp.write(re.sub(' +',' ',''.join(chr if chr.isalnum() else ' ' for chr in json.loads(line)['reviewText'].lower()))+'\n')

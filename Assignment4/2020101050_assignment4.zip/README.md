<h1>README
    
</h1>

**ELMo Model for SST Dataset:** [ELMo Model 1](https://iiitaphyd-my.sharepoint.com/:u:/g/personal/abhishek_shar_students_iiit_ac_in/ER7oBbL6UrpErp279lINvO0BWmNxIo80qOSCe6lWkXVWAg?e=KqxE3m)

**ELMo Model for Multi-NLI Dataset:** [ELMo Model 2](https://iiitaphyd-my.sharepoint.com/:u:/g/personal/abhishek_shar_students_iiit_ac_in/EaRQANkhRkxNmFLmwgLJO38BJFa6UivQp9FyyaFxxFTvrg?e=kDVhLT)

**ELMo Embedding 1 :** [Elmo Embedding 1](https://iiitaphyd-my.sharepoint.com/:u:/g/personal/abhishek_shar_students_iiit_ac_in/Ef87_xFGiYFHjXJPHLou2tgBZq2j7Qq-jij9PgVRABWaHw?e=y0Q9eZ)

**ELMo Embedding 2:** [Elmo Embedding 2](https://iiitaphyd-my.sharepoint.com/:u:/g/personal/abhishek_shar_students_iiit_ac_in/Ef87_xFGiYFHjXJPHLou2tgBZq2j7Qq-jij9PgVRABWaHw?e=y0Q9eZ)

**ELMo Classifier 1:** [ELMo Classfier 1](https://iiitaphyd-my.sharepoint.com/:u:/g/personal/abhishek_shar_students_iiit_ac_in/Ef87_xFGiYFHjXJPHLou2tgBZq2j7Qq-jij9PgVRABWaHw?e=y0Q9eZ) 

**ELMo Classifier 2:** [ELMo Classifier 2](https://iiitaphyd-my.sharepoint.com/:u:/g/personal/abhishek_shar_students_iiit_ac_in/EbUPvUIHDhpCiWPsyEx36yoB8rWq4_34ad1YYS3BmWd9Ow?e=tDRVab) 



For the flow of code, use ``code.ipynb`` . 